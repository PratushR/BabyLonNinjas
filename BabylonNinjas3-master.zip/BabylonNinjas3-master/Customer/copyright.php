<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Copyright Information Page</title>
    <link rel="stylesheet" href="navbar.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>
<body style="background-color:aqua">
    
                            <div class = "navbar">
								<a href='babycare.php'>Baby Care Products</a>
								<a href='diseases.php'>Diseases</a>
								<a href='Vaccination.php'>Vaccination</a>
								<a href='foodnutrition.php'>Food & Nutrition</a>
								<a href='logout.php'>Logout</a>


                            </div>
                            <br/>
                            <br/>
                            <div style="background-color:black; height:500px; width:700px; border: 1px solid-red; border-radius:10px; margin-left:400px;">
                                <h2 style="color:white; text-align:center;">Copyright Information</h2>

                            </div>
                             
                            <br/>
                            <br/>


                            <div class = "footer">
        
								<a href='feedback.php'>Feedback</a>
									<a href='copyright.php'>Copyright</a>
									<a href='address.php'>Address</a>
							</div>
</body>
</html>
<html>
						<head>
							<link rel="stylesheet" href="navbar.css"/>
                            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
                            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
						<title></title>
						</head>
						<body >

							<div class = "navbar">
								<a href='babycare.php'>Baby Care Products</a>
								<a href='diseases.php'>Diseases</a>
								<a href='Vaccination.php'>Vaccination</a>
								<a href='foodnutrition.php'>Food & Nutrition</a>
								<a href='logout.php'>Logout</a>


							</div>


							<div id="h" style="margin-left: 220px; margin-right:auto;">

						    <h1 style="color:red";>Common Diseases in Child with Tips to Cope Them</h1>
							</div>

							<div id="main" style="background-color: gold;">

							<br/>
							<br/>
					        <form action="" method="">
						        <div id ="dv1" style="margin-left:350px;">
						            <img src ="dis1.jpg" alt = "No Image Found"> <br/>
                                        <b style="color:white;">Sore Throat in Children Remedies</b>
                                        <p style="background-color: aqua;">Sore throats are common in children and can be painful. However, a sore throat that is caused by a virus does not need antibiotics. In those cases, no specific medicine is required, and your child should get better in seven to ten days. In other cases, a sore throat could be caused by an infection called streptococcal (strep throat).

                                            Strep cannot be accurately diagnosed by simply looking at the throat. A lab test or in-office rapid strep test, which includes a quick swab of the throat, is necessary to confirm the diagnosis of strep. If positive for strep, your pediatrician will prescribe an antibiotic. It's very important that your child take the antibiotic for the full course, as prescribed, even if the symptoms get better or go away. Steroid medicines (such as prednisone) are not an appropriate treatment for most cases of sore throat.
                                            
                                            Babies and toddlers rarely get it strep throat, but they are more likely to become infected by streptococcus bacteria if they are in child care or if an older sibling has the illness. Although strep spreads mainly through coughs and sneezes, your child can also get it by touching a toy that an infected child has played with.
                                            
                                            </p>
						                
						                    <br/>
								</div>
								<br/>
								<br/>
								<br/>
						         &nbsp;
								 <div id ="dv1" style="margin-left:350px;">
						            <img src = "dis2.jpg" alt = "No Image Found"> <br/>
						                <b style="color:white;">Diarehha / Chronic Diarrhea</b>
						                <p style="background-color: blanchedalmond;">Toddler’s diarrhea
                                            For toddler’s diarrhea, treatment is usually not needed. Most children outgrow toddler’s diarrhea by the time they start school (around age 5). In many children, reducing sugar-sweetened beverages and increasing the amount of fiber and fat in the diet may improve symptoms of toddler’s diarrhea.
                                            
                                            Irritable bowel syndrome
                                            A doctor may treat your child’s irritable bowel syndrome with changes in what your child eats and medicines.</p>   
						                    <br/>
								</div>

                                <br/>
								<br/>
                                <br/>
                                <br/>


								<div id ="dv1" style="margin-left:350px;">
						            <img src = "dis3.jpg" alt = "No Image Found" style="height: 300px; width: 400px;"> <br/>
						                <b style="color:white;">Pnuemonia in Children</b>
						                <p style="background-color: chartreuse;"> Let your child rest and sleep as much as possible. Your child may be more tired than usual. Rest and sleep help your child's body heal.
                                            Give your child liquids as directed. Liquids help your child to loosen mucus and keeps him or her from becoming dehydrated. Ask how much liquid your child should drink each day and which liquids are best for him or her. Your child's healthcare provider may recommend water, apple juice, gelatin, broth, and popsicles.
                                            Use a cool mist humidifier to increase air moisture in your home. This may make it easier for your child to breathe and help decrease his or her cough.</p>
						                    <br/>
								</div>

								<br/>
								<br/>
								<br/>

								<div id ="dv1" style="margin-left:350px;">
						            <img src = "dis4.jpg" alt = "No Image Found" style="height:200px; width:400px;"> <br/>
						                <b style="color:white;">Food Eating Disorder</b>
						                <p style="background-color: antiquewhite;">If your child is under the age of 18, they can begin treatment even if they don’t yet recognize they have an eating disorder. Don’t trust your child to evaluate whether they’re healthy or not, as people with eating disorders struggle to think objectively about their health and often deny they have a problem. If your child is over 18 and refuses treatment, consider using financial leverage and continued conversations to express your concerns. Medical guardianship must be court-ordered and is difficult to obtain, but sometimes it will be granted in life-or-death situations.</p>
						                    <br/>
								</div>
								<br/>

                                <br/>
								<br/>
								<br/>

								<div id ="dv1" style="margin-left:350px;">
						            <img src = "dis5.jpg" alt = "No Image Found"> <br/>
						                <b style="color:white;">Cold and Cough</b>
						            <p style="background-color: bisque;">1. Steam: If your little one suffers from cold and has trouble breathing, get him/her to take steam. Make the kid stand in the bathroom with hot water running or simply heat water in a wide bowl and make the kid inhale the hot fumes for at least 10 to 15 minutes. Adding eucalyptus oil can also help soothe your child’s system.
										2. Honey: Known for its soothing effect, dip your finger in honey and let your baby lick it two three times in a day. If your child is older than five years, mix a spoonful with cinnamon powder and ask him/her to have it.
										3. Carom Seeds: Boiling water along with carom seeds (ajwain) and tulsi leaves can help to keep the cough in check. It also helps in relieving chest congestion.
										4. Massage: Massages work best for children who are below two years of age. Mix mustard oil with garlic and massage your baby’s chest, back and neck area. Also cover the baby’s palm and feet with the oil for a quick relief.
										5. Keep your kid hydrated: When your kid is going through a bout of sneezing and coughing, it is very important to keep him/her hydrated. Drinking water at regular intervals will help fight the common cold and reduce the inflammation in the throat along with washing out the infection. Other fluids in form of warm soup or a fresh juice are also beneficial for replenishing the body’s lost energy.
										6. Salt gargling: A glass of hot water with a teaspoon of salt can be useful to ease a sore throat. Ask your kid to gargle with salt water twice a day. The saline water helps soothe the pain.
										7. Turmeric milk: Due to its antiseptic properties, turmeric is known to treat viral infections such as cough and cold. Add turmeric powder to a glass of warm milk and make your kid have it every night. It provides instant relief for an aching throat and runny nose. Since it is a rich source of calcium, milk also provides energy to your kid.
										 </p>
										
										<br/>
									</div>
								<br/>
								<br/>

								<div id ="dv1" style="margin-left:350px;">
						            <img src = "dis6.jpg" alt = "No Image Found" style=" height: 300px; width:400px;"> <br/>
						                <b style="color:white;">Learning Disability in Children</b>
						                <p style="background-color: cornflowerblue;">Extra help: A reading specialist or other trained professional can teach your child techniques to improve his or her academic skills. Tutors can also teach children organizational and study skills.

											Individualized Education Program (IEP): Your child's school or a special educator might develop an IEP that will describe how a child can best learn in school.
											
											Therapy: Depending on the learning disorder, some children might benefit from therapy. For example, speech therapy can help children who have language disabilities. Occupational therapy might help improve the motor skills of a child who has writing problems.
											
											Complimentary/alternative therapy: Research shows that alternative therapies like music, art, dance can benefit children with learning disabilities.
										</p>   
						                    <br/>
								</div>
								<br/>
								<br/>
								<br/>


            

							<div class = "footer">
        
								<a href='feedback.php'>Feedback</a>
									<a href='copyright.php'>Copyright</a>
									<a href='address.php'>Address</a>
							</div>
							
							
	
						</body>

						</html>
		



 



Download the zip file.

Download and install XAMPP

Run the XAMPP control panel and start MySQL and Apache

Go to C:\xampp\htdocs and extract the downloaded zip file (downloaded) inside the folder

Open the browser and go to http://localhost/phpmyadmin/ to create the database

Click the new to create a database.

Name the database babycare.

Click import to import the sql file.

Click choose file and select the file that can be found inside the downloaded folder

Click go



For Admin side start:---> localhost/(folder name in c/xammp/htdocs/foldername)/Admin/signup.php

For Customer side start:---> localhost/(folder name in c/xammp/htdocs/foldername)/Customer/signup.php


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="navbar.css"/>
    <title>Document</title>
</head>
<body bgcolor="aqua">
    

    <div class = "navbar">
        
        <a href='login.php'>Login</a>
        <a href='signup.php'>Sign Up</a>
    </div>


    <br/>
    <br/>
    <br/>
    <br/>
    <h1 style="margin-left: 400px;">Welcome to Baby Care Products System</h1>
    <br/>
    <br/>
    <div id="h1" style="background-image: url('babygood.jpg'); height: 800px; width:800px; margin-left:300px;">
        <img src ="babygood.jpg" style="height:800px; width:800px;">
        
        
    </div>
    

    <br/>
    <br/>

    <div class = "footer">
        
            
    </div>
    
</body>
</html>